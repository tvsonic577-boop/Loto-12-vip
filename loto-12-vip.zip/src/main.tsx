import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Prevenir erros de estruturas circulares ao enviar logs para o interceptador do iframe do AI Studio
(() => {
  const safeClone = (obj: any, seen = new WeakSet()): any => {
    if (obj === null || typeof obj !== 'object') {
      if (typeof obj === 'function') {
        return `[Function: ${obj.name || 'anonymous'}]`;
      }
      return obj;
    }
    if (obj instanceof Date) {
      return obj.toISOString();
    }
    if (obj instanceof RegExp) {
      return obj.toString();
    }
    if (obj instanceof Error) {
      return {
        name: obj.name,
        message: obj.message,
        code: (obj as any).code,
        stack: obj.stack,
      };
    }
    if (typeof Element !== 'undefined' && obj instanceof Element) {
      return `[Element: ${obj.tagName.toLowerCase()}]`;
    }
    if (seen.has(obj)) {
      return '[Circular]';
    }
    seen.add(obj);

    if (Array.isArray(obj)) {
      return obj.map(item => safeClone(item, seen));
    }

    const clone: any = {};
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        try {
          clone[key] = safeClone(obj[key], seen);
        } catch (e) {
          clone[key] = '[Unreadable property]';
        }
      }
    }
    return clone;
  };

  const wrapConsole = (method: string) => {
    const original = (console as any)[method];
    if (typeof original === 'function') {
      (console as any)[method] = function (...args: any[]) {
        const safeArgs = args.map(arg => {
          try {
            return safeClone(arg);
          } catch (e) {
            return '[Serialization Error]';
          }
        });
        original.apply(console, safeArgs);
      };
    }
  };

  wrapConsole('log');
  wrapConsole('error');
  wrapConsole('warn');
  wrapConsole('info');
  wrapConsole('debug');
})();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
