import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dns from "dns";

// Ensure localhost resolves correctly
dns.setDefaultResultOrder("ipv4first");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// In-memory store for mock payments
interface MockPayment {
  id: string;
  amount: number;
  status: "pending" | "approved";
  createdAt: number;
}
const mockPayments = new Map<string, MockPayment>();

// API Routes

// 1. Create payment (PIX)
app.post("/api/create-payment", async (req, res) => {
  const { amount, description, email, btcCount } = req.body;

  if (!amount || amount <= 0) {
    res.status(400).json({ error: "Invalid amount" });
    return;
  }

  const accessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN;

  if (accessToken && accessToken.trim() !== "") {
    try {
      console.log(`Generating real Mercado Pago PIX payment for amount: R$ ${amount}`);
      const response = await fetch("https://api.mercadopago.com/v1/payments", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken.trim()}`,
          "Content-Type": "application/json",
          "X-Idempotency-Key": `idemp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`
        },
        body: JSON.stringify({
          transaction_amount: Number(amount),
          description: description || "Aposta - Loteria VIP",
          payment_method_id: "pix",
          payer: {
            email: email || "tvsonic577@gmail.com",
            first_name: "Cliente",
            last_name: "VIP"
          }
        })
      });

      if (!response.ok) {
        const errBody = await response.text();
        console.error("Mercado Pago API error response:", errBody);
        throw new Error(`Mercado Pago error: ${response.statusText} - ${errBody}`);
      }

      const data = await response.json();
      console.log("Real Mercado Pago payment created successfully with ID:", data.id);

      const qrCode = data.point_of_interaction?.transaction_data?.qr_code || "";
      const qrCodeBase64 = data.point_of_interaction?.transaction_data?.qr_code_base64 || "";

      res.json({
        id: String(data.id),
        status: data.status, // "pending", "approved", etc.
        qrCode,
        qrCodeBase64,
        isMock: false,
        amount: Number(amount)
      });
      return;
    } catch (error: any) {
      console.error("Error creating real Mercado Pago payment:", error);
      // Fall back gracefully to mock if real payment generation fails
    }
  }

  // Fallback / Mock payment creation
  console.log(`Generating MOCK PIX payment for amount: R$ ${amount}`);
  const mockId = `mock_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const cleanAmountStr = Number(amount).toFixed(2);
  
  // Real-looking PIX Copy & Paste string
  const mockQrCode = `00020101021226830014br.gov.bcb.pix2561api.mercadopago.com/v2/ticket/990234471/${mockId}5204000053039865405${cleanAmountStr}5802BR5911LOTERIA VIP6009SAO PAULO62070503***63048D2A`;
  
  const newMockPayment: MockPayment = {
    id: mockId,
    amount: Number(amount),
    status: "pending",
    createdAt: Date.now()
  };

  mockPayments.set(mockId, newMockPayment);

  // Auto-approve mock payments after 15 seconds to simulate real-world success
  setTimeout(() => {
    const p = mockPayments.get(mockId);
    if (p && p.status === "pending") {
      p.status = "approved";
      console.log(`Mock payment ${mockId} automatically approved after timeout.`);
    }
  }, 12000);

  res.json({
    id: mockId,
    status: "pending",
    qrCode: mockQrCode,
    qrCodeBase64: "", // Will render client side using API or inline placeholder
    isMock: true,
    amount: Number(amount)
  });
});

// 2. Check payment status
app.get("/api/payment-status/:id", async (req, res) => {
  const paymentId = req.params.id;

  if (paymentId.startsWith("mock_")) {
    const payment = mockPayments.get(paymentId);
    if (!payment) {
      res.status(404).json({ error: "Payment not found" });
      return;
    }
    res.json({
      id: paymentId,
      status: payment.status,
      isMock: true
    });
    return;
  }

  const accessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN;
  if (!accessToken || accessToken.trim() === "") {
    res.status(400).json({ error: "Mercado Pago access token not configured" });
    return;
  }

  try {
    const response = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
      headers: {
        "Authorization": `Bearer ${accessToken.trim()}`
      }
    });

    if (!response.ok) {
      throw new Error(`Mercado Pago check error: ${response.statusText}`);
    }

    const data = await response.json();
    res.json({
      id: String(data.id),
      status: data.status, // "pending", "approved", etc.
      isMock: false
    });
  } catch (error: any) {
    console.error("Error checking Mercado Pago payment status:", error);
    res.status(500).json({ error: error.message || "Failed to check status" });
  }
});

// 3. Force simulate payment success (for test UI button)
app.post("/api/simulate-payment-success/:id", (req, res) => {
  const paymentId = req.params.id;
  const payment = mockPayments.get(paymentId);
  if (!payment) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }
  payment.status = "approved";
  console.log(`Mock payment ${paymentId} manually approved via developer simulation.`);
  res.json({ success: true, status: "approved" });
});


// Serve Frontend via Vite Middleware in dev, Static Files in prod
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

setupServer();
